# CardioPredict AI 2.0 — Aplicación Streamlit (Entregable 2)
**Especialización en Inteligencia Artificial — Corporación Unificada Nacional de Educación Superior (CUN)**  
**Asignatura:** Aprendizaje Automático — ACA 2  
**Docente:** Dr. Hamilton Rivera Flor  
**Equipo Investigador:**  
- Marcela Avila Beltrán  
- Jaime Andres Cabrera Avendaño  
- Cristhian Javier Garzon Jimenez  
- Johan Smith Valderrama Sanchez  

---

## 🫀 Descripción General
Esta aplicación web interactiva desarrollada en **Streamlit** permite la inferencia clínica asistida en tiempo real mediante modelos de **Deep Learning (PyTorch)** entrenados para la detección de riesgo de cardiopatía (Pilar Salud, 918 pacientes multicéntricos).

### Características Principales:
1. **Inferencia Dual con Redes Neuronales:**
   - **Deep MLP (Perceptrón Multicapa Profundo):** Arquitectura principal optimizada con penalización asimétrica de Falsos Negativos (Recall: **93.14%**).
   - **1D-CNN (Red Convolucional 1D):** Extracción local de patrones clínicos continuos.
2. **Consola Interactiva SQL:**
   - Conexión nativa a la base de datos relacional SQLite (`database/cardiopredict.db`) con auditoría de esquemas, consultas predefinidas y queries libres.
3. **Semáforo Clínico y Triaje Inteligente:**
   - Clasificación de riesgo (Bajo / Moderado / Crítico) con recomendaciones de derivación según guías internacionales AHA/ACC.
4. **Calibrador Dinámico de Umbral de Decisión:**
   - Ajuste interactivo del threshold (tau entre 0.10 y 0.90) para maximizar la sensibilidad clínica en servicios de urgencias.

---

## 🚀 Requisitos e Instalación

### 1. Requisitos Previos
- Python 3.9 o superior.
- Gestor de paquetes `pip`.

### 2. Instalación de Dependencias
Se recomienda crear un entorno virtual para aislar las dependencias:

```bash
# Crear entorno virtual
python3 -m venv venv

# Activar entorno virtual
# En macOS / Linux:
source venv/bin/activate
# En Windows:
venv\Scripts\activate

# Instalar requerimientos
pip install -r requirements.txt
```

---

## ▶️ Ejecución de la Aplicación

Para iniciar la aplicación localmente, ejecute:

```bash
streamlit run app.py
```

La aplicación se abrirá automáticamente en su navegador en `http://localhost:8501`.

### Scripts Rápidos de Inicio:
- **macOS / Linux:** `./run_app.sh`
- **Windows:** Doble clic en `run_app.bat`

---

## 📁 Estructura del Paquete
```
CardioPredict_AI_2_App_Streamlit/
├── app.py                     # Código fuente principal de la aplicación Streamlit
├── requirements.txt           # Dependencias exactas del proyecto
├── README.md                  # Manual técnico de instalación y ejecución
├── run_app.sh                 # Script de arranque para macOS / Linux
├── run_app.bat                # Script de arranque para Windows
├── favicon.png                # Icono institucional médico
├── visor_codigo.html          # Vista HTML del código fuente
├── models/                    # Modelos y pesos entrenados en PyTorch
│   ├── cardiopredict_deep_mlp.pt    # Pesos entrenados Deep MLP
│   ├── cardiopredict_1d_cnn.pt      # Pesos entrenados 1D-CNN
│   ├── preprocessor.joblib          # Pipeline de escalado RobustScaler + OneHotEncoder
│   └── metrics_summary.json         # Resumen de métricas de desempeño
├── database/                  # Base de datos relacional estructurada
│   ├── cardiopredict.db             # SQLite con 918 registros indexados
│   └── database_manager.py          # Gestor de conexión y consultas SQL
└── assets/                    # Curvas de aprendizaje y recursos visuales
    ├── accuracy_curves.png
    ├── loss_curves.png
    ├── confusion_matrix_deep_learning.png
    ├── roc_curve_deep_learning.png
    ├── head_to_head_comparison.png
    └── qr_code_aca2.png
```

---

## 🌐 Despliegue en la Nube
Si prefiere auditar la aplicación sin realizar una instalación local, se encuentra disponible 24/7 en producción:
- **Portal Central ACA 2:** https://iacun.lat/aprendizajeautomatico/aca2/
- **App Streamlit en Vivo:** https://iacun.lat/aprendizajeautomatico/aca2/app/
