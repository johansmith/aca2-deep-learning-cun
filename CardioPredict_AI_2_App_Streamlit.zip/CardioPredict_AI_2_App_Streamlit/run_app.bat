@echo off
echo ==================================================
echo Iniciando CardioPredict AI 2.0 (Streamlit)...
echo ==================================================
streamlit run app.py
pause
